# Master version for Pillow
__version__ = '5.4.1'
